@extends('admin.layout.app')

@section('title', 'Create New Post')
@section('page-title', 'Create New Post')

@section('page-actions')
<a href="{{ route('admin.posts.index') }}" class="btn btn-outline-secondary">
    <i class="fas fa-arrow-left me-2"></i><span class="d-none d-sm-inline">Back to Posts</span><span class="d-sm-none">Back</span>
</a>
@endsection

@push('styles')
<style>
/* Mobile Responsive Styles */
@media (max-width: 992px) {
    .sidebar-sticky {
        position: relative !important;
        height: auto !important;
    }

    .mobile-sidebar-card {
        margin-bottom: 1rem;
    }

    .mobile-main-content {
        margin-bottom: 2rem;
    }
}

@media (max-width: 768px) {
    .quill-editor-container .ql-toolbar {
        padding: 0.5rem;
    }

    .quill-editor-container .ql-editor {
        min-height: 200px;
        padding: 0.75rem;
    }

    .form-control, .form-select {
        font-size: 16px; /* Prevents zoom on iOS */
    }

    .card-header h5 {
        font-size: 1.1rem;
    }

    .btn {
        padding: 0.5rem 1rem;
    }

    .page-actions {
        margin-bottom: 1rem;
    }

    .mobile-action-buttons {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: white;
        border-top: 1px solid #dee2e6;
        padding: 1rem;
        z-index: 1020;
        box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
    }

    .mobile-action-buttons .btn {
        font-size: 0.9rem;
    }

    .mobile-content-padding {
        padding-bottom: 100px; /* Space for fixed buttons */
    }

    .tags-container {
        max-height: 150px;
        overflow-y: auto;
    }

    .social-media-row {
        margin-bottom: 1rem;
    }
}

@media (max-width: 576px) {
    .card-body {
        padding: 1rem;
    }

    .card-header {
        padding: 0.75rem 1rem;
    }

    .form-label {
        font-size: 0.9rem;
        margin-bottom: 0.25rem;
    }

    .form-text {
        font-size: 0.8rem;
    }

    .badge {
        font-size: 0.7rem;
    }

    .mobile-action-buttons {
        padding: 0.75rem;
    }

    .mobile-action-buttons .btn {
        padding: 0.75rem;
        font-size: 0.85rem;
    }

    .quill-editor-container .ql-toolbar .ql-formats {
        margin-right: 0.5rem;
    }

    .page-title-mobile {
        font-size: 1.25rem;
    }
}

/* Responsive Quill Toolbar */
@media (max-width: 480px) {
    .quill-editor-container .ql-toolbar {
        border-bottom: 1px solid #ccc;
    }

    .quill-editor-container .ql-toolbar .ql-formats {
        margin-right: 0.25rem;
    }

    .quill-editor-container .ql-toolbar button {
        padding: 0.25rem;
        width: 28px;
        height: 28px;
    }
}
</style>
@endpush

@section('content')
<div class="mobile-content-padding">
    <form action="{{ route('admin.posts.store') }}" method="POST" enctype="multipart/form-data" id="post-form">
        @csrf

        <div class="row">
            <!-- Main Content -->
            <div class="col-lg-8 mobile-main-content">
                <!-- Basic Information -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Basic Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="title" class="form-label">Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" id="title" class="form-control @error('title') is-invalid @enderror"
                                   value="{{ old('title') }}" required onkeyup="generateSlug()">
                            @error('title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="slug" class="form-label">Slug</label>
                            <input type="text" name="slug" id="slug" class="form-control @error('slug') is-invalid @enderror"
                                   value="{{ old('slug') }}">
                            <div class="form-text">Leave empty to auto-generate from title</div>
                            @error('slug')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
    <label for="excerpt" class="form-label">Excerpt <span class="text-danger">*</span></label>
    <textarea name="excerpt" id="excerpt" class="form-control @error('excerpt') is-invalid @enderror"
              rows="4" maxlength="300" required
              placeholder="Write a brief description of your post (plain text only)...">{{ old('excerpt', $post->excerpt ?? '') }}</textarea>
    <div class="form-text">
        <span id="excerpt-counter">0/300 characters</span> - Brief description of the post (150-160 characters recommended for SEO)
    </div>
    @error('excerpt')
        <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>

                        <div class="mb-3">
                            <label for="content" class="form-label">Content <span class="text-danger">*</span></label>
                            <div class="quill-editor-container">
                                <div class="quill-editor" data-editor-id="content"></div>
                            </div>
                            <textarea name="content" id="content" style="display: none;" required>{{ old('content') }}</textarea>
                            @error('content')
                                <div class="invalid-feedback d-block">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="featured_image" class="form-label">Featured Image</label>
                            <input type="file" name="featured_image" id="featured_image"
                                   class="form-control @error('featured_image') is-invalid @enderror"
                                   accept="image/*" onchange="previewImage(this)">
                            <div class="form-text">Recommended size: 1200x630px for optimal social media sharing</div>
                            @error('featured_image')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div id="image-preview" class="mt-2"></div>
                        </div>
                    </div>
                </div>

                <!-- SEO Settings -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-search me-2"></i>SEO Settings
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="meta_title" class="form-label">Meta Title</label>
                            <input type="text" name="meta_title" id="meta_title" class="form-control @error('meta_title') is-invalid @enderror"
                                   value="{{ old('meta_title') }}" maxlength="60">
                            <div class="form-text">60 characters max. Leave empty to use post title.</div>
                            @error('meta_title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="meta_description" class="form-label">Meta Description</label>
                            <textarea name="meta_description" id="meta_description" class="form-control @error('meta_description') is-invalid @enderror"
                                      rows="3" maxlength="160">{{ old('meta_description') }}</textarea>
                            <div class="form-text">160 characters max. Leave empty to use excerpt.</div>
                            @error('meta_description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="focus_keyword" class="form-label">Focus Keyword</label>
                                <input type="text" name="focus_keyword" id="focus_keyword" class="form-control @error('focus_keyword') is-invalid @enderror"
                                       value="{{ old('focus_keyword') }}">
                                <div class="form-text">Primary keyword you want this post to rank for</div>
                                @error('focus_keyword')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="canonical_url" class="form-label">Canonical URL</label>
                                <input type="url" name="canonical_url" id="canonical_url" class="form-control @error('canonical_url') is-invalid @enderror"
                                       value="{{ old('canonical_url') }}">
                                <div class="form-text">Leave empty to use default post URL</div>
                                @error('canonical_url')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="meta_keywords" class="form-label">Meta Keywords</label>
                            <input type="text" name="meta_keywords" id="meta_keywords" class="form-control @error('meta_keywords') is-invalid @enderror"
                                   value="{{ old('meta_keywords') }}">
                            <div class="form-text">Comma-separated keywords</div>
                            @error('meta_keywords')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <!-- Social Media Settings -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-share-alt me-2"></i>Social Media Settings
                        </h5>
                    </div>
                    <div class="card-body">
                        <h6>Open Graph (Facebook, LinkedIn)</h6>
                        <div class="row social-media-row">
                            <div class="col-md-6 mb-3">
                                <label for="og_title" class="form-label">OG Title</label>
                                <input type="text" name="og_title" id="og_title" class="form-control @error('og_title') is-invalid @enderror"
                                       value="{{ old('og_title') }}">
                                @error('og_title')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="og_image" class="form-label">OG Image URL</label>
                                <input type="url" name="og_image" id="og_image" class="form-control @error('og_image') is-invalid @enderror"
                                       value="{{ old('og_image') }}">
                                @error('og_image')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="og_description" class="form-label">OG Description</label>
                            <textarea name="og_description" id="og_description" class="form-control @error('og_description') is-invalid @enderror"
                                      rows="2">{{ old('og_description') }}</textarea>
                            @error('og_description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <h6 class="mt-4">Twitter Card</h6>
                        <div class="row social-media-row">
                            <div class="col-md-6 mb-3">
                                <label for="twitter_title" class="form-label">Twitter Title</label>
                                <input type="text" name="twitter_title" id="twitter_title" class="form-control @error('twitter_title') is-invalid @enderror"
                                       value="{{ old('twitter_title') }}">
                                @error('twitter_title')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="twitter_image" class="form-label">Twitter Image URL</label>
                                <input type="url" name="twitter_image" id="twitter_image" class="form-control @error('twitter_image') is-invalid @enderror"
                                       value="{{ old('twitter_image') }}">
                                @error('twitter_image')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="twitter_description" class="form-label">Twitter Description</label>
                            <textarea name="twitter_description" id="twitter_description" class="form-control @error('twitter_description') is-invalid @enderror"
                                      rows="2">{{ old('twitter_description') }}</textarea>
                            @error('twitter_description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Publish Settings -->
                <div class="card mb-4 mobile-sidebar-card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Publish Settings</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                            <select name="status" id="status" class="form-select @error('status') is-invalid @enderror" required>
                                <option value="draft" {{ old('status', 'draft') === 'draft' ? 'selected' : '' }}>Draft</option>
                                <option value="published" {{ old('status') === 'published' ? 'selected' : '' }}>Published</option>
                                <option value="archived" {{ old('status') === 'archived' ? 'selected' : '' }}>Archived</option>
                            </select>
                            @error('status')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="published_at" class="form-label">Publish Date</label>
                            <input type="datetime-local" name="published_at" id="published_at"
                                   class="form-control @error('published_at') is-invalid @enderror"
                                   value="{{ old('published_at') }}">
                            <div class="form-text">Leave empty to publish immediately when status is set to published</div>
                            @error('published_at')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <div class="form-check">
                                <input type="checkbox" name="is_featured" id="is_featured" class="form-check-input" value="1" {{ old('is_featured') ? 'checked' : '' }}>
                                <label class="form-check-label" for="is_featured">
                                    <i class="fas fa-star text-warning me-1"></i>Featured Post
                                </label>
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="form-check">
                                <input type="checkbox" name="allow_comments" id="allow_comments" class="form-check-input" value="1" {{ old('allow_comments', true) ? 'checked' : '' }}>
                                <label class="form-check-label" for="allow_comments">
                                    <i class="fas fa-comments me-1"></i>Allow Comments
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Author -->
                <div class="card mb-4 mobile-sidebar-card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Author</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="staff_id" class="form-label">Author <span class="text-danger">*</span></label>
                            <select name="staff_id" id="staff_id" class="form-select @error('staff_id') is-invalid @enderror" required>
                                <option value="">Select Author</option>
                                @foreach($authors as $author)
                                <option value="{{ $author->id }}" {{ old('staff_id') == $author->id ? 'selected' : '' }}>
                                    {{ $author->name }} ({{ $author->position }})
                                </option>
                                @endforeach
                            </select>
                            @error('staff_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <!-- Category -->
                <div class="card mb-4 mobile-sidebar-card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Category</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="post_category_id" class="form-label">Category <span class="text-danger">*</span></label>
                            <select name="post_category_id" id="post_category_id" class="form-select @error('post_category_id') is-invalid @enderror" required>
                                <option value="">Select Category</option>
                                @foreach($categories as $category)
                                <option value="{{ $category->id }}" {{ old('post_category_id') == $category->id ? 'selected' : '' }}>
                                    {{ $category->name }}
                                </option>
                                @endforeach
                            </select>
                            @error('post_category_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <!-- Tags -->
                <div class="card mb-4 mobile-sidebar-card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Tags</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Select Tags</label>
                            <div class="border rounded p-3 tags-container">
                                @foreach($tags as $tag)
                                <div class="form-check mb-2">
                                    <input type="checkbox" name="tags[]" id="tag_{{ $tag->id }}" class="form-check-input"
                                           value="{{ $tag->id }}" {{ in_array($tag->id, old('tags', [])) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="tag_{{ $tag->id }}">
                                        <span class="badge" style="background-color: {{ $tag->color }}">{{ $tag->name }}</span>
                                    </label>
                                </div>
                                @endforeach
                            </div>
                            @error('tags')
                                <div class="invalid-feedback d-block">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <!-- Desktop Actions -->
                <div class="card d-none d-md-block">
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <button type="submit" name="action" value="save" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Save Post
                            </button>
                            <button type="submit" name="action" value="save_and_continue" class="btn btn-outline-primary">
                                <i class="fas fa-edit me-2"></i>Save & Continue Editing
                            </button>
                            <a href="{{ route('admin.posts.index') }}" class="btn btn-outline-secondary">
                                <i class="fas fa-times me-2"></i>Cancel
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- Mobile Action Buttons -->
<div class="mobile-action-buttons d-md-none">
    <div class="d-grid gap-2">
        <div class="row g-2">
            <div class="col-6">
                <button type="submit" form="post-form" name="action" value="save" class="btn btn-primary w-100">
                    <i class="fas fa-save me-1"></i>Save Post
                </button>
            </div>
            <div class="col-6">
                <a href="{{ route('admin.posts.index') }}" class="btn btn-outline-secondary w-100">
                    <i class="fas fa-times me-1"></i>Cancel
                </a>
            </div>
        </div>
        <button type="submit" form="post-form" name="action" value="save_and_continue" class="btn btn-outline-primary w-100">
            <i class="fas fa-edit me-1"></i>Save & Continue Editing
        </button>
    </div>
</div>
@endsection

@push('scripts')
<script>
// Generate slug from title
function generateSlug() {
    const title = document.getElementById('title').value;
    const slug = title.toLowerCase()
        .replace(/[^\w ]+/g, '')
        .replace(/ +/g, '-');
    document.getElementById('slug').value = slug;
}

// Preview uploaded image
function previewImage(input) {
    const preview = document.getElementById('image-preview');
    preview.innerHTML = '';

    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.innerHTML = `<img src="${e.target.result}" class="img-thumbnail" style="max-width: 200px;">`;
        };
        reader.readAsDataURL(input.files[0]);
    }
}


// Excerpt character counter
document.getElementById('excerpt').addEventListener('input', function() {
    updateExcerptCharacterCount(this);
});

document.getElementById('meta_description').addEventListener('input', function() {
    updateCharacterCount(this, 160);
});

function updateCharacterCount(element, maxLength) {
    const current = element.value.length;
    const remaining = maxLength - current;
    const color = remaining < 0 ? 'text-danger' : (remaining < 20 ? 'text-warning' : 'text-muted');

    let counter = element.parentNode.querySelector('.char-counter');
    if (!counter) {
        counter = document.createElement('div');
        counter.className = 'char-counter form-text';
        element.parentNode.appendChild(counter);
    }

    counter.className = `char-counter form-text ${color}`;
    counter.textContent = `${current}/${maxLength} characters`;
}

function updateExcerptCharacterCount(element) {
    const current = element.value.length;
    const maxLength = 300;
    const remaining = maxLength - current;
    const color = remaining < 0 ? 'text-danger' : (remaining < 50 ? 'text-warning' : 'text-muted');

    const counter = document.getElementById('excerpt-counter');
    if (counter) {
        counter.className = `form-text ${color}`;
        counter.textContent = `${current}/${maxLength} characters`;
    }
}

// Initialize excerpt character counter on page load
document.addEventListener('DOMContentLoaded', function() {
    const excerptField = document.getElementById('excerpt');
    if (excerptField) {
        updateExcerptCharacterCount(excerptField);
    }
});
// Prevent form submission when clicking mobile action buttons
// document.addEventListener('DOMContentLoaded', function() {
//     // Handle mobile form submission
//     const mobileButtons = document.querySelectorAll('.mobile-action-buttons button[type="submit"]');
//     mobileButtons.forEach(button => {
//         button.addEventListener('click', function(e) {
//             e.preventDefault();
//             const form = document.getElementById('post-form');
//             const actionInput = document.createElement('input');
//             actionInput.type = 'hidden';
//             actionInput.name = 'action';
//             actionInput.value = this.getAttribute('name') === 'action' ? this.value : 'save';
//             form.appendChild(actionInput);
//             form.submit();
//         });
//     });
// });
</script>
@endpush
