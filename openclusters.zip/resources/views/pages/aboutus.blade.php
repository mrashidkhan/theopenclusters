@extends('layouts.master')

@section('content')
    @include('partials.aboutsection')
    @include('partials.teamsection')
@endsection
