@extends('layouts.master')

@section('content')


    @include('partials.testimonialsection')


@endsection
