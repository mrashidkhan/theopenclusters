@extends('layouts.master')

@section('title', 'Home')

@section('page-title', 'Home')

@section('content')


    @include('partials.aboutsection')
    

@endsection
