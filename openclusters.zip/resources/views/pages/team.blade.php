@extends('layouts.master')

@section('content')


    @include('partials.teamsection')


@endsection
