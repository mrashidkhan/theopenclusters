@extends('layouts.master')

@section('content')


    @include('partials.projectsection')


@endsection
