@extends('layouts.master')

@section('content')


    @include('partials.clientsection')


@endsection
