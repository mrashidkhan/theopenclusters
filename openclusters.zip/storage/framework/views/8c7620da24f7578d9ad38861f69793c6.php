<?php $__env->startSection('content'); ?>


    <?php echo $__env->make('partials.testimonialsection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\openclusters\resources\views\pages\testimonials.blade.php ENDPATH**/ ?>