<?php $__env->startSection('title', 'Staff Profile: ' . $staff->name); ?>
<?php $__env->startSection('page-title', 'Staff Profile'); ?>

<?php $__env->startSection('page-actions'); ?>
<div class="d-flex gap-2">
    <a href="<?php echo e(route('admin.staff.edit', $staff)); ?>" class="btn btn-primary">
        <i class="fas fa-edit me-2"></i>Edit Profile
    </a>
    <a href="<?php echo e(route('admin.staff.index')); ?>" class="btn btn-outline-secondary">
        <i class="fas fa-arrow-left me-2"></i>Back to Staff
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Staff Profile -->
    <div class="col-lg-8">
        <div class="card">
            <div class="card-body">
                <!-- Profile Header -->
                <div class="d-flex align-items-center mb-4">
                    <img src="<?php echo e($staff->avatar_url); ?>" class="rounded-circle me-4" width="100" height="100" alt="<?php echo e($staff->name); ?>">
                    <div>
                        <h2 class="mb-1"><?php echo e($staff->name); ?></h2>
                        <?php if($staff->position): ?>
                            <h5 class="text-muted mb-2"><?php echo e($staff->position); ?></h5>
                        <?php endif; ?>
                        <div class="d-flex align-items-center mb-2">
                            <?php if($staff->status === 'active'): ?>
                                <span class="badge bg-success me-2">Active</span>
                            <?php else: ?>
                                <span class="badge bg-secondary me-2">Inactive</span>
                            <?php endif; ?>
                            <small class="text-muted">Member since <?php echo e($staff->created_at->format('M Y')); ?></small>
                        </div>

                        <!-- Social Links -->
                        <?php if($staff->social_links): ?>
                        <div class="social-links">
                            <?php $__currentLoopData = $staff->social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($url): ?>
                                    <a href="<?php echo e($url); ?>" target="_blank" class="btn btn-outline-secondary btn-sm me-2" title="<?php echo e(ucfirst($platform)); ?>">
                                        <i class="fab fa-<?php echo e($platform); ?>"></i>
                                    </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Contact Information -->
                <div class="mb-4">
                    <h5>Contact Information</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-2">
                                <i class="fas fa-envelope me-2 text-muted"></i>
                                <a href="mailto:<?php echo e($staff->email); ?>"><?php echo e($staff->email); ?></a>
                            </div>
                            <?php if($staff->phone): ?>
                            <div class="mb-2">
                                <i class="fas fa-phone me-2 text-muted"></i>
                                <a href="tel:<?php echo e($staff->phone); ?>"><?php echo e($staff->phone); ?></a>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-2">
                                <i class="fas fa-link me-2 text-muted"></i>
                                <code><?php echo e($staff->slug); ?></code>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bio -->
                <?php if($staff->bio): ?>
                <div class="mb-4">
                    <h5>About</h5>
                    <p class="text-muted"><?php echo e($staff->bio); ?></p>
                </div>
                <?php endif; ?>

                <!-- Recent Posts -->
                <?php if($recentPosts->count() > 0): ?>
                <div class="mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5>Recent Posts</h5>
                        <?php if($staff->posts()->count() > $recentPosts->count()): ?>
                            <a href="<?php echo e(route('admin.posts.index', ['author' => $staff->id])); ?>" class="btn btn-sm btn-outline-primary">
                                View All Posts (<?php echo e($staff->posts()->count()); ?>)
                            </a>
                        <?php endif; ?>
                    </div>

                    <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex mb-3 <?php echo e(!$loop->last ? 'border-bottom pb-3' : ''); ?>">
                        <?php if($post->featured_image): ?>
                            <img src="<?php echo e($post->featured_image_url); ?>" class="rounded me-3" width="60" height="60" style="object-fit: cover;" alt="">
                        <?php endif; ?>
                        <div class="flex-grow-1">
                            <h6 class="mb-1">
                                <a href="<?php echo e(route('admin.posts.show', $post)); ?>" class="text-decoration-none">
                                    <?php echo e($post->title); ?>

                                </a>
                            </h6>
                            <div class="small text-muted mb-1">
                                <span class="badge" style="background-color: <?php echo e($post->category->color); ?>; font-size: 0.7rem;">
                                    <?php echo e($post->category->name); ?>

                                </span>
                                <span class="ms-2"><?php echo e($post->published_date ?: 'Draft'); ?></span>
                                <?php if($post->is_featured): ?>
                                    <span class="badge bg-warning text-dark ms-1">Featured</span>
                                <?php endif; ?>
                            </div>
                            <p class="mb-0 small text-muted"><?php echo e(Str::limit($post->excerpt, 100)); ?></p>
                            <div class="small text-muted">
                                <?php echo e($post->views_count); ?> views • <?php echo e($post->approvedComments->count()); ?> comments
                            </div>
                        </div>
                        <div class="text-end">
                            <?php if($post->status === 'published'): ?>
                                <span class="badge bg-success">Published</span>
                            <?php elseif($post->status === 'draft'): ?>
                                <span class="badge bg-secondary">Draft</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark"><?php echo e(ucfirst($post->status)); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        <!-- Statistics -->
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Statistics</h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-6 mb-3">
                        <h3 class="text-primary mb-1"><?php echo e($staff->posts_count); ?></h3>
                        <small class="text-muted">Total Posts</small>
                    </div>
                    <div class="col-6 mb-3">
                        <h3 class="text-success mb-1"><?php echo e($staff->published_posts_count); ?></h3>
                        <small class="text-muted">Published</small>
                    </div>
                    <div class="col-6">
                        <h3 class="text-info mb-1"><?php echo e($staff->posts()->where('status', 'draft')->count()); ?></h3>
                        <small class="text-muted">Drafts</small>
                    </div>
                    <div class="col-6">
                        <h3 class="text-warning mb-1"><?php echo e($staff->posts()->sum('views_count')); ?></h3>
                        <small class="text-muted">Total Views</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Actions -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Actions</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('admin.staff.edit', $staff)); ?>" class="btn btn-primary">
                        <i class="fas fa-edit me-2"></i>Edit Profile
                    </a>

                    <form method="POST" action="<?php echo e(route('admin.staff.toggle-status', $staff)); ?>" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="btn btn-outline-secondary w-100">
                            <i class="fas fa-toggle-<?php echo e($staff->status === 'active' ? 'on' : 'off'); ?> me-2"></i>
                            <?php echo e($staff->status === 'active' ? 'Deactivate' : 'Activate'); ?>

                        </button>
                    </form>

                    <?php if($staff->posts()->count() > 0): ?>
                    <a href="<?php echo e(route('admin.posts.index', ['author' => $staff->id])); ?>" class="btn btn-outline-info">
                        <i class="fas fa-file-alt me-2"></i>View All Posts
                    </a>
                    <?php endif; ?>

                    <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-outline-success">
                        <i class="fas fa-plus me-2"></i>Create New Post
                    </a>
                </div>
            </div>
        </div>

        <!-- Staff Information -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Information</h5>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label fw-bold">Full Name:</label>
                    <div><?php echo e($staff->name); ?></div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Email:</label>
                    <div><?php echo e($staff->email); ?></div>
                </div>

                <?php if($staff->position): ?>
                <div class="mb-3">
                    <label class="form-label fw-bold">Position:</label>
                    <div><?php echo e($staff->position); ?></div>
                </div>
                <?php endif; ?>

                <?php if($staff->phone): ?>
                <div class="mb-3">
                    <label class="form-label fw-bold">Phone:</label>
                    <div><?php echo e($staff->phone); ?></div>
                </div>
                <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label fw-bold">URL Slug:</label>
                    <div><code><?php echo e($staff->slug); ?></code></div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Status:</label>
                    <div>
                        <?php if($staff->status === 'active'): ?>
                            <span class="badge bg-success">Active</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Inactive</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Member Since:</label>
                    <div><?php echo e($staff->created_at->format('M d, Y')); ?></div>
                </div>

                <?php if($staff->updated_at != $staff->created_at): ?>
                <div class="mb-3">
                    <label class="form-label fw-bold">Last Updated:</label>
                    <div><?php echo e($staff->updated_at->format('M d, Y')); ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Navigation -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Quick Navigation</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <?php if($staff->posts()->where('status', 'draft')->count() > 0): ?>
                    <a href="<?php echo e(route('admin.posts.index', ['author' => $staff->id, 'status' => 'draft'])); ?>" class="btn btn-outline-warning">
                        <i class="fas fa-edit me-2"></i>Draft Posts (<?php echo e($staff->posts()->where('status', 'draft')->count()); ?>)
                    </a>
                    <?php endif; ?>

                    <?php if($staff->posts()->where('status', 'published')->count() > 0): ?>
                    <a href="<?php echo e(route('admin.posts.index', ['author' => $staff->id, 'status' => 'published'])); ?>" class="btn btn-outline-success">
                        <i class="fas fa-eye me-2"></i>Published Posts (<?php echo e($staff->posts()->where('status', 'published')->count()); ?>)
                    </a>
                    <?php endif; ?>

                    <a href="<?php echo e(route('admin.staff.index')); ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-users me-2"></i>All Staff Members
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\openclusters\resources\views\admin\staff\show.blade.php ENDPATH**/ ?>