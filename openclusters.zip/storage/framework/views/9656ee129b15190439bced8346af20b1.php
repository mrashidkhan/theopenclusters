<?php $__env->startSection('content'); ?>

<!-- Page Header Start -->
<div class="container-fluid page-header py-5">
    <div class="container text-center py-5">
        <h1 class="display-2 text-white mb-4 animated slideInDown">Our Blogs</h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                <li class="breadcrumb-item text-white" aria-current="page">Blogs</li>
            </ol>
        </nav>
    </div>
</div>
<!-- Page Header End -->

<!-- Blog Section Start -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="row g-5">
            <!-- Main Content -->
            <div class="col-lg-8">
                <!-- Search and Filter -->
                <div class="row mb-4">
                    <div class="col-md-8">
                        <form method="GET" action="<?php echo e(route('blogs')); ?>">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control" placeholder="Search blogs..." value="<?php echo e(request('search')); ?>">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fas fa-search"></i> Search
                                </button>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-4">
                        <form method="GET" action="<?php echo e(route('blogs')); ?>">
                            <select name="category" class="form-select" onchange="this.form.submit()">
                                <option value="">All Categories</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->slug); ?>" <?php echo e(request('category') == $category->slug ? 'selected' : ''); ?>>
                                        <?php echo e($category->name); ?> (<?php echo e($category->posts_count); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </form>
                    </div>
                </div>

                <!-- Results Info -->
                <?php if(request('search') || request('category')): ?>
                <div class="alert alert-info">
                    <strong><?php echo e($totalPosts ?? $blogs->count()); ?></strong> posts found
                    <?php if(request('search')): ?>
                        for "<strong><?php echo e(request('search')); ?></strong>"
                    <?php endif; ?>
                    <?php if(request('category')): ?>
                        in category "<strong><?php echo e($categories->where('slug', request('category'))->first()->name ?? request('category')); ?></strong>"
                    <?php endif; ?>
                    <a href="<?php echo e(route('blogs')); ?>" class="ms-3 text-decoration-none">Clear filters</a>
                </div>
                <?php endif; ?>

                <!-- Blog Posts Grid -->
                <?php if($blogs->count() > 0): ?>
                    <div class="row g-4" id="blog-posts-container">
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-4 blog-post-item">
                            <div class="blog-item bg-light rounded h-100">
                                <div class="position-relative">
                                    <img src="<?php echo e($blog->featured_image_url); ?>" class="img-fluid w-100 rounded-top" style="height: 250px; object-fit: cover;" alt="<?php echo e($blog->title); ?>">
                                    <span class="position-absolute top-0 end-0 m-3 px-3 py-1 bg-primary text-white rounded">
                                        <?php echo e($blog->category->name); ?>

                                    </span>
                                    <?php if($blog->is_featured): ?>
                                        <span class="position-absolute top-0 start-0 m-3 badge bg-warning text-dark">Featured</span>
                                    <?php endif; ?>
                                </div>

                                <div class="p-4 d-flex flex-column">
                                    <div class="d-flex align-items-center mb-3">
                                        <img src="<?php echo e($blog->staff->avatar_url); ?>" class="rounded-circle me-2" style="width: 30px; height: 30px; object-fit: cover;" alt="<?php echo e($blog->staff->name); ?>">
                                        <small class="text-muted">By <?php echo e($blog->staff->name); ?></small>
                                        <small class="text-muted ms-auto"><?php echo e($blog->published_date); ?></small>
                                    </div>

                                    <h5 class="mb-3">
                                        <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="text-decoration-none text-dark">
                                            <?php echo e($blog->title); ?>

                                        </a>
                                    </h5>

                                    <p class="text-muted mb-3 flex-grow-1"><?php echo e(Str::limit($blog->excerpt, 120)); ?></p>

                                    <div class="d-flex justify-content-between align-items-center mt-auto">
                                        <div class="d-flex">
                                            <small class="text-muted me-3">
                                                <i class="fas fa-eye me-1"></i><?php echo e(number_format($blog->views_count ?? 0)); ?>

                                            </small>
                                            <small class="text-muted me-3">
                                                <i class="fas fa-comments me-1"></i><?php echo e($blog->approvedComments->count()); ?>

                                            </small>
                                            <small class="text-muted">
                                                <i class="fas fa-clock me-1"></i><?php echo e($blog->reading_time ?? 5); ?> min
                                            </small>
                                        </div>
                                        <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="btn btn-primary btn-sm">Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <!-- Load More Button -->
                    <?php if(isset($totalPosts) && $totalPosts > $blogs->count()): ?>
                    <div class="text-center mt-5" id="load-more-container">
                        <button id="load-more-btn" class="btn btn-primary btn-lg px-5">
                            <i class="fas fa-plus me-2"></i>Load More Posts
                            <span class="badge bg-light text-primary ms-2"><?php echo e($totalPosts - $blogs->count()); ?> remaining</span>
                        </button>
                        <div id="loading-spinner" class="d-none mt-3">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <p class="mt-2 text-muted">Loading more posts...</p>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php else: ?>
                    <!-- No Results -->
                    <div class="text-center py-5">
                        <i class="fas fa-search fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">No blog posts found</h4>
                        <p class="text-muted">
                            <?php if(request('search') || request('category')): ?>
                                Try adjusting your search criteria or <a href="<?php echo e(route('blogs')); ?>">view all posts</a>.
                            <?php else: ?>
                                Check back later for new content.
                            <?php endif; ?>
                        </p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Featured Posts -->
                <?php if($featuredPosts->count() > 0): ?>
                <div class="bg-light rounded p-4 mb-4">
                    <h4 class="mb-4">Featured Posts</h4>
                    <?php $__currentLoopData = $featuredPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex mb-3 <?php echo e(!$loop->last ? 'border-bottom pb-3' : ''); ?>">
                        <img src="<?php echo e($post->featured_image_url); ?>" class="rounded me-3" style="width: 60px; height: 60px; object-fit: cover;" alt="<?php echo e($post->title); ?>">
                        <div>
                            <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="h6 text-decoration-none"><?php echo e(Str::limit($post->title, 50)); ?></a>
                            <small class="text-muted d-block"><?php echo e($post->published_date); ?></small>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <!-- Categories -->
                <?php if($categories->count() > 0): ?>
                <div class="bg-light rounded p-4 mb-4">
                    <h4 class="mb-4">Categories</h4>
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mb-2">
                            <a href="<?php echo e(route('blogs')); ?>?category=<?php echo e($category->slug); ?>" class="text-decoration-none d-flex justify-content-between">
                                <span><?php echo e($category->name); ?></span>
                                <span class="badge bg-secondary"><?php echo e($category->posts_count); ?></span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <!-- Recent Posts -->
                <?php
                    $recentPosts = App\Models\Post::with(['staff', 'category'])
                        ->where('status', 'published')
                        ->orderBy('published_at', 'desc')
                        ->take(5)
                        ->get();
                ?>
                <?php if($recentPosts->count() > 0): ?>
                <div class="bg-light rounded p-4 mb-4">
                    <h4 class="mb-4">Recent Posts</h4>
                    <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex mb-3 <?php echo e(!$loop->last ? 'border-bottom pb-3' : ''); ?>">
                        <img src="<?php echo e($post->featured_image_url); ?>" class="rounded me-3" style="width: 50px; height: 50px; object-fit: cover;" alt="<?php echo e($post->title); ?>">
                        <div>
                            <a href="<?php echo e(route('blog.show', $post->slug)); ?>" class="text-decoration-none"><?php echo e(Str::limit($post->title, 45)); ?></a>
                            <small class="text-muted d-block"><?php echo e($post->published_date); ?></small>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <!-- Newsletter Signup -->
                <div class="bg-primary text-white rounded p-4">
                    <h4 class="mb-3">Stay Updated</h4>
                    <p class="mb-3">Subscribe to our newsletter to get the latest blog posts delivered to your inbox.</p>
                    <form>
                        <div class="mb-3">
                            <input type="email" class="form-control" placeholder="Your email address" required>
                        </div>
                        <button type="submit" class="btn btn-light w-100">Subscribe</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Blog Section End -->

<!-- JavaScript directly in the template -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const loadMoreBtn = document.getElementById('load-more-btn');

    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            const loadingSpinner = document.getElementById('loading-spinner');
            const blogContainer = document.getElementById('blog-posts-container');
            const loadMoreContainer = document.getElementById('load-more-container');

            // Show loading state
            loadMoreBtn.style.display = 'none';
            loadingSpinner.classList.remove('d-none');

            // Get current search parameters
            const urlParams = new URLSearchParams(window.location.search);
            const searchParam = urlParams.get('search') || '';
            const categoryParam = urlParams.get('category') || '';

            // Build AJAX URL
            let ajaxUrl = `<?php echo e(route('blogs')); ?>?load_more=1`;
            if (searchParam) ajaxUrl += `&search=${encodeURIComponent(searchParam)}`;
            if (categoryParam) ajaxUrl += `&category=${encodeURIComponent(categoryParam)}`;

            // Make AJAX request
            fetch(ajaxUrl, {
                method: 'GET',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                if (!data.success || !Array.isArray(data.blogs)) {
                    throw new Error('Invalid response format');
                }

                // Clear existing posts
                blogContainer.innerHTML = '';

                // Add all posts
                data.blogs.forEach(blog => {
                    const featuredBadge = blog.is_featured ?
                        '<span class="position-absolute top-0 start-0 m-3 badge bg-warning text-dark">Featured</span>' : '';

                    const blogHtml = `
                        <div class="col-md-6 mb-4 blog-post-item">
                            <div class="blog-item bg-light rounded h-100">
                                <div class="position-relative">
                                    <img src="${blog.featured_image_url}" class="img-fluid w-100 rounded-top" style="height: 250px; object-fit: cover;" alt="${blog.title}">
                                    <span class="position-absolute top-0 end-0 m-3 px-3 py-1 bg-primary text-white rounded">
                                        ${blog.category_name}
                                    </span>
                                    ${featuredBadge}
                                </div>
                                <div class="p-4 d-flex flex-column">
                                    <div class="d-flex align-items-center mb-3">
                                        <img src="${blog.staff_avatar_url}" class="rounded-circle me-2" style="width: 30px; height: 30px; object-fit: cover;" alt="${blog.staff_name}">
                                        <small class="text-muted">By ${blog.staff_name}</small>
                                        <small class="text-muted ms-auto">${blog.published_date}</small>
                                    </div>
                                    <h5 class="mb-3">
                                        <a href="${blog.blog_show_url}" class="text-decoration-none text-dark">
                                            ${blog.title}
                                        </a>
                                    </h5>
                                    <p class="text-muted mb-3 flex-grow-1">${blog.excerpt}</p>
                                    <div class="d-flex justify-content-between align-items-center mt-auto">
                                        <div class="d-flex">
                                            <small class="text-muted me-3">
                                                <i class="fas fa-eye me-1"></i>${blog.views_count.toLocaleString()}
                                            </small>
                                            <small class="text-muted me-3">
                                                <i class="fas fa-comments me-1"></i>${blog.comments_count}
                                            </small>
                                            <small class="text-muted">
                                                <i class="fas fa-clock me-1"></i>${blog.reading_time} min
                                            </small>
                                        </div>
                                        <a href="${blog.blog_show_url}" class="btn btn-primary btn-sm">Read More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                    blogContainer.insertAdjacentHTML('beforeend', blogHtml);
                });

                // Hide load more section
                loadMoreContainer.style.display = 'none';
            })
            .catch(error => {
                // Reset UI and show error
                loadingSpinner.classList.add('d-none');
                loadMoreBtn.style.display = 'block';
                loadMoreBtn.innerHTML = '<i class="fas fa-exclamation-triangle me-2"></i>Error loading posts. Try again.';
                loadMoreBtn.classList.remove('btn-primary');
                loadMoreBtn.classList.add('btn-danger');
            });
        });
    }
});
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\openclusters\resources\views\pages\blogs.blade.php ENDPATH**/ ?>