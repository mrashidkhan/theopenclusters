<!-- Team Start -->
<div class="container-fluid py-5 mb-5 team">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" data-wow-delay=".3s" style="max-width: 600px;">
            <h5 class="text-primary">Our Team</h5>
            <h1>Meet our expert Team</h1>
        </div>

        <?php
            $teamMembers = \App\Models\Staff::active()->orderBy('name')->get();
        ?>

        <?php if($teamMembers->count() > 0): ?>
        <div class="owl-carousel team-carousel wow fadeIn" data-wow-delay=".5s">
            <?php $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded team-item">
                <div class="team-content">
                    <div class="team-img-icon">
                        <div class="team-img rounded-circle">
                            <img src="<?php echo e($member->avatar_url); ?>" class="img-fluid w-100 rounded-circle" alt="<?php echo e($member->name); ?>">
                        </div>
                        <div class="team-name text-center py-3">
                            <h4 class=""><?php echo e($member->name); ?></h4>
                            <p class="m-0"><?php echo e($member->position ?? 'Team Member'); ?></p>
                        </div>
                        <div class="team-icon d-flex justify-content-center pb-4">
                            <?php if($member->social_links && is_array($member->social_links)): ?>
                                <?php if(isset($member->social_links['facebook']) && $member->social_links['facebook']): ?>
                                <a class="btn btn-square btn-secondary text-white rounded-circle m-1" href="<?php echo e($member->social_links['facebook']); ?>" target="_blank">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <?php endif; ?>

                                <?php if(isset($member->social_links['twitter']) && $member->social_links['twitter']): ?>
                                <a class="btn btn-square btn-secondary text-white rounded-circle m-1" href="<?php echo e($member->social_links['twitter']); ?>" target="_blank">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <?php endif; ?>

                                <?php if(isset($member->social_links['instagram']) && $member->social_links['instagram']): ?>
                                <a class="btn btn-square btn-secondary text-white rounded-circle m-1" href="<?php echo e($member->social_links['instagram']); ?>" target="_blank">
                                    <i class="fab fa-instagram"></i>
                                </a>
                                <?php endif; ?>

                                <?php if(isset($member->social_links['linkedin']) && $member->social_links['linkedin']): ?>
                                <a class="btn btn-square btn-secondary text-white rounded-circle m-1" href="<?php echo e($member->social_links['linkedin']); ?>" target="_blank">
                                    <i class="fab fa-linkedin-in"></i>
                                </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <!-- Default social icons if no social links provided -->
                                <a class="btn btn-square btn-secondary text-white rounded-circle m-1" href="#"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square btn-secondary text-white rounded-circle m-1" href="#"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-square btn-secondary text-white rounded-circle m-1" href="#"><i class="fab fa-instagram"></i></a>
                                <a class="btn btn-square btn-secondary text-white rounded-circle m-1" href="#"><i class="fab fa-linkedin-in"></i></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
        <!-- Fallback if no team members in database -->
        <div class="text-center">
            <p class="text-muted">Our amazing team information will be available soon.</p>
        </div>
        <?php endif; ?>
    </div>
</div>
<!-- Team End -->
<?php /**PATH D:\Laravel\openclusters\resources\views\partials\teamsection.blade.php ENDPATH**/ ?>