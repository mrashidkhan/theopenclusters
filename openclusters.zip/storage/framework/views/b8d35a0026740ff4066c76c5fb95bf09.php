<?php $__env->startSection('content'); ?>

<!-- Page Header Start -->
<div class="container-fluid page-header py-5">
    <div class="container text-center py-5">
        <h1 class="display-4 text-white mb-4 animated slideInDown"><?php echo e($blog->title); ?></h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('blogs')); ?>">Blogs</a></li>
                <li class="breadcrumb-item text-white" aria-current="page"><?php echo e($blog->category->name); ?></li>
            </ol>
        </nav>
    </div>
</div>
<!-- Page Header End -->
<!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
<!-- Blog Details Start -->
<div class="container-fluid py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-8">
                <!-- Blog Post -->
                <div class="blog-item bg-light rounded">
                    <img src="<?php echo e($blog->featured_image_url); ?>" class="img-fluid w-100 rounded-top" alt="<?php echo e($blog->title); ?>">

                    <div class="p-4">
                        <div class="d-flex justify-content-between mb-3">
                            <span class="px-4 py-2 bg-primary text-white rounded"><?php echo e($blog->category->name); ?></span>
                            <small class="text-muted"><?php echo e($blog->published_date); ?></small>
                        </div>

                        <h2 class="mb-3"><?php echo e($blog->title); ?></h2>

                        <div class="d-flex align-items-center mb-3">
                            <img src="<?php echo e($blog->staff->avatar_url); ?>" class="img-fluid rounded-circle me-3" style="width: 50px; height: 50px; object-fit: cover;" alt="<?php echo e($blog->staff->name); ?>">
                            <div>
                                <h6 class="mb-1"><?php echo e($blog->staff->name); ?></h6>
                                <small class="text-muted"><?php echo e($blog->staff->position ?? 'Author'); ?></small>
                            </div>
                        </div>

                        <?php if($blog->excerpt): ?>
                        <p class="mb-4 lead"><?php echo e($blog->excerpt); ?></p>
                        <?php endif; ?>

                        <div class="blog-content">
                            <?php echo $blog->content; ?>

                        </div>

                        <!-- Post Meta Info -->
                        <div class="row mt-4 pt-3 border-top">
                            <div class="col-md-6">
                                <small class="text-muted">
                                    <i class="fas fa-clock me-1"></i> <?php echo e($blog->reading_time_text); ?>

                                </small>
                            </div>
                            <div class="col-md-6 text-end">
                                <small class="text-muted">
                                    <i class="fas fa-eye me-1"></i> <?php echo e(number_format($blog->views_count ?? 0)); ?> views
                                </small>
                            </div>
                        </div>

                        <!-- Tags -->
                        <?php if($blog->tags->count() > 0): ?>
                        <div class="mt-3">
                            <strong>Tags: </strong>
                            <?php $__currentLoopData = $blog->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-secondary me-1"><?php echo e($tag->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>

                        <!-- Social Share -->
                        <div class="d-flex justify-content-between align-items-center mt-4 pt-4 border-top">
                            <div class="d-flex">
                                <span class="me-3"><i class="fas fa-eye me-2 text-primary"></i><?php echo e(number_format($blog->views_count ?? 0)); ?> Views</span>
                                <span><i class="fa fa-comments me-2 text-primary"></i><?php echo e($blog->approvedComments->count()); ?> Comments</span>
                            </div>
                            <div>
                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(request()->url())); ?>" target="_blank" class="btn btn-outline-primary btn-sm me-2"><i class="fab fa-facebook-f"></i></a>
                                <a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(request()->url())); ?>&text=<?php echo e(urlencode($blog->title)); ?>" target="_blank" class="btn btn-outline-primary btn-sm me-2"><i class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e(urlencode(request()->url())); ?>" target="_blank" class="btn btn-outline-primary btn-sm me-2"><i class="fab fa-linkedin-in"></i></a>
                                <a href="#" onclick="navigator.clipboard.writeText('<?php echo e(request()->url()); ?>')" class="btn btn-outline-primary btn-sm"><i class="fas fa-link"></i></a>
                            </div>
                        </div>

                        <!-- Navigation -->
                        <?php if($previousPost || $nextPost): ?>
                        <div class="row mt-4 pt-4 border-top">
                            <div class="col-md-6">
                                <?php if($previousPost): ?>
                                <a href="<?php echo e(route('blog.show', $previousPost->slug)); ?>" class="text-decoration-none">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-chevron-left me-2"></i>
                                        <div>
                                            <small class="text-muted">Previous Post</small>
                                            <h6 class="mb-0"><?php echo e(Str::limit($previousPost->title, 30)); ?></h6>
                                        </div>
                                    </div>
                                </a>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6 text-end">
                                <?php if($nextPost): ?>
                                <a href="<?php echo e(route('blog.show', $nextPost->slug)); ?>" class="text-decoration-none">
                                    <div class="d-flex align-items-center justify-content-end">
                                        <div class="text-end">
                                            <small class="text-muted">Next Post</small>
                                            <h6 class="mb-0"><?php echo e(Str::limit($nextPost->title, 30)); ?></h6>
                                        </div>
                                        <i class="fas fa-chevron-right ms-2"></i>
                                    </div>
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Comments Section -->
                <div class="bg-light rounded p-4 mt-4">
                    <h4 class="mb-4">Comments (<?php echo e($blog->approvedComments->count()); ?>)</h4>

                    <?php if($blog->approvedComments->count() > 0): ?>
                        <?php $__currentLoopData = $blog->approvedComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex mb-4 <?php echo e(!$loop->last ? 'border-bottom pb-4' : ''); ?>">
                            <img src="<?php echo e($comment->avatar); ?>" class="img-fluid rounded-circle me-3" style="width: 50px; height: 50px;" alt="<?php echo e($comment->name); ?>">
                            <div class="flex-grow-1">
                                <div class="d-flex justify-content-between">
                                    <h6><?php echo e($comment->name); ?></h6>
                                    <small class="text-muted"><?php echo e($comment->created_at->diffForHumans()); ?></small>
                                </div>
                                <p class="mb-0"><?php echo nl2br(e($comment->content)); ?></p>

                                <?php if($comment->website): ?>
                                <small class="text-muted">
                                    <a href="<?php echo e($comment->website); ?>" target="_blank" class="text-decoration-none">
                                        <i class="fas fa-external-link-alt me-1"></i>Website
                                    </a>
                                </small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p class="text-muted">No comments yet. Be the first to comment!</p>
                    <?php endif; ?>

                    <!-- Add Comment Form -->
<?php if($blog->allow_comments): ?>
<div class="mt-4">
    <h5>Leave a Comment</h5>

    <!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Validation Errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('blog.comments.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="post_id" value="<?php echo e($blog->id); ?>">
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="Your Name*" value="<?php echo e(old('name')); ?>" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="mb-3">
                    <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="Your Email*" value="<?php echo e(old('email')); ?>" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        <div class="mb-3">
            <input type="url" name="website" class="form-control <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                   placeholder="Your Website (Optional)" value="<?php echo e(old('website')); ?>">
            <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <textarea name="content" class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      rows="4" placeholder="Your Comment*" required><?php echo e(old('content')); ?></textarea>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="btn btn-primary">Post Comment</button>
    </form>
</div>
<?php else: ?>
    <div class="alert alert-info">
        <i class="fas fa-info-circle me-2"></i>Comments are disabled for this post.
    </div>
<?php endif; ?>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Recent Posts -->
                <?php if($relatedBlogs->count() > 0): ?>
                <div class="bg-light rounded p-4 mb-4">
                    <h4 class="mb-4">Related Posts</h4>
                    <?php $__currentLoopData = $relatedBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex mb-3 <?php echo e(!$loop->last ? 'border-bottom pb-3' : ''); ?>">
                        <img src="<?php echo e($relatedBlog->featured_image_url); ?>" class="img-fluid rounded" style="width: 80px; height: 80px; object-fit: cover;" alt="<?php echo e($relatedBlog->title); ?>">
                        <div class="ms-3">
                            <a href="<?php echo e(route('blog.show', $relatedBlog->slug)); ?>" class="h6 text-decoration-none"><?php echo e(Str::limit($relatedBlog->title, 50)); ?></a>
                            <small class="text-muted d-block"><?php echo e($relatedBlog->published_date); ?></small>
                            <small class="text-muted">By <?php echo e($relatedBlog->staff->name); ?></small>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <!-- Categories -->
                <?php
                    $categories = App\Models\PostCategory::where('status', 'active')
                        ->withCount(['posts' => function($query) {
                            $query->where('status', 'published');
                        }])
                        ->orderBy('name')
                        ->get();
                ?>
                <?php if($categories->count() > 0): ?>
                <div class="bg-light rounded p-4 mb-4">
                    <h4 class="mb-4">Categories</h4>
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mb-2">
                            <a href="<?php echo e(route('blogs.category', $category->slug)); ?>" class="text-decoration-none">
                                <?php echo e($category->name); ?> <span class="text-muted">(<?php echo e($category->posts_count); ?>)</span>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <!-- Tags -->
                <?php
                    $popularTags = App\Models\PostTag::where('status', 'active')
                        ->withCount('publishedPosts')
                        ->orderBy('published_posts_count', 'desc')
                        ->take(10)
                        ->get();
                ?>
                <?php if($popularTags->count() > 0): ?>
                <div class="bg-light rounded p-4">
                    <h4 class="mb-4">Popular Tags</h4>
                    <div>
                        <?php $__currentLoopData = $popularTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('blogs.tag', $tag->slug)); ?>" class="btn btn-outline-primary btn-sm me-2 mb-2">
                            <?php echo e($tag->name); ?>

                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<!-- Blog Details End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\openclusters\resources\views\pages\blog-single.blade.php ENDPATH**/ ?>