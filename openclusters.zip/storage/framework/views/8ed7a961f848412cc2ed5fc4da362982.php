<?php $__env->startSection('title', 'Comments Management'); ?>
<?php $__env->startSection('page-title', 'Comments Management'); ?>

<?php $__env->startSection('page-actions'); ?>
<div class="d-flex gap-2">
    <a href="<?php echo e(route('admin.comments.pending')); ?>" class="btn btn-warning">
        <i class="fas fa-clock me-2"></i>Pending Comments
        <?php
            $pendingCount = \App\Models\PostComment::where('status', 'pending')->count();
        ?>
        <?php if($pendingCount > 0): ?>
            <span class="badge bg-danger ms-1"><?php echo e($pendingCount); ?></span>
        <?php endif; ?>
    </a>
    <a href="<?php echo e(route('admin.comments.spam')); ?>" class="btn btn-outline-danger">
        <i class="fas fa-exclamation-triangle me-2"></i>Spam Comments
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.comments.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <input type="text" name="search" class="form-control" placeholder="Search comments..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select">
                    <option value="">All Status</option>
                    <option value="pending" <?php echo e(request('status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="approved" <?php echo e(request('status') === 'approved' ? 'selected' : ''); ?>>Approved</option>
                    <option value="spam" <?php echo e(request('status') === 'spam' ? 'selected' : ''); ?>>Spam</option>
                    <option value="rejected" <?php echo e(request('status') === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="post" class="form-select">
                    <option value="">All Posts</option>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($post->id); ?>" <?php echo e(request('post') == $post->id ? 'selected' : ''); ?>>
                        <?php echo e(Str::limit($post->title, 50)); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-outline-primary me-2">
                    <i class="fas fa-search me-1"></i>Filter
                </button>
                <a href="<?php echo e(route('admin.comments.index')); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-1"></i>Clear
                </a>
            </div>
        </form>
    </div>
</div>

<!-- Comments Table -->
<div class="card">
    <div class="card-body">
        <?php if($comments->count() > 0): ?>
            <!-- Bulk Actions -->
            <div class="bulk-actions mb-3" style="display: none;">
                <form method="POST" action="<?php echo e(route('admin.comments.bulk-action')); ?>" onsubmit="return confirm('Are you sure you want to perform this action on selected comments?')" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="comments" id="bulk-comments">
                    <div class="d-flex align-items-center gap-2">
                        <select name="action" class="form-select" style="width: auto;" required>
                            <option value="">Select Action</option>
                            <option value="approve">Approve</option>
                            <option value="reject">Reject</option>
                            <option value="spam">Mark as Spam</option>
                            <option value="delete">Delete</option>
                        </select>
                        <button type="submit" class="btn btn-primary btn-sm">Apply</button>
                        <button type="button" class="btn btn-secondary btn-sm" onclick="clearSelection()">Cancel</button>
                    </div>
                </form>
            </div>

            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th width="50">
                                <input type="checkbox" id="select-all" onchange="toggleSelectAll(this)">
                            </th>
                            <th>Author</th>
                            <th>Comment</th>
                            <th>Post</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th width="150">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e($comment->status === 'pending' ? 'table-warning' : ($comment->status === 'spam' ? 'table-danger' : '')); ?>">
                            <td>
                                <input type="checkbox" name="items[]" value="<?php echo e($comment->id); ?>" onchange="updateBulkActions()">
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="<?php echo e($comment->avatar); ?>" class="rounded-circle me-2" width="32" height="32" alt="">
                                    <div>
                                        <h6 class="mb-1"><?php echo e($comment->name); ?></h6>
                                        <small class="text-muted"><?php echo e($comment->email); ?></small>
                                        <?php if($comment->website): ?>
                                            <div><a href="<?php echo e($comment->website); ?>" target="_blank" class="small text-muted"><?php echo e($comment->website); ?></a></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <p class="mb-1"><?php echo e(Str::limit($comment->content, 100)); ?></p>
                                <?php if($comment->parent_id): ?>
                                    <small class="text-muted">
                                        <i class="fas fa-reply me-1"></i>Reply to <?php echo e($comment->parent->name); ?>

                                    </small>
                                <?php endif; ?>
                                <?php if($comment->is_featured): ?>
                                    <span class="badge bg-warning text-dark ms-2">Featured</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.posts.show', $comment->post)); ?>" class="text-decoration-none">
                                    <?php echo e(Str::limit($comment->post->title, 40)); ?>

                                </a>
                            </td>
                            <td>
                                <?php if($comment->status === 'approved'): ?>
                                    <span class="badge bg-success">Approved</span>
                                <?php elseif($comment->status === 'pending'): ?>
                                    <span class="badge bg-warning text-dark">Pending</span>
                                <?php elseif($comment->status === 'spam'): ?>
                                    <span class="badge bg-danger">Spam</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e(ucfirst($comment->status)); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="small">
                                    <div><?php echo e($comment->created_at->format('M d, Y')); ?></div>
                                    <div class="text-muted"><?php echo e($comment->created_at->format('h:i A')); ?></div>
                                </div>
                            </td>
                            <td>
                                <div class="table-actions">
                                    <a href="<?php echo e(route('admin.comments.show', $comment)); ?>" class="btn btn-sm btn-outline-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>

                                    <?php if($comment->status === 'pending'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.comments.approve', $comment)); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-success" title="Approve">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>

                                    <?php if($comment->status !== 'spam'): ?>
                                    <form method="POST" action="<?php echo e(route('admin.comments.spam', $comment)); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-warning" title="Mark as Spam">
                                            <i class="fas fa-exclamation-triangle"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>

                                    <a href="<?php echo e(route('admin.comments.edit', $comment)); ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>

                                    <form method="POST" action="<?php echo e(route('admin.comments.destroy', $comment)); ?>" class="d-inline" onsubmit="return confirmDelete('Are you sure you want to delete this comment?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-between align-items-center mt-4">
                <div class="text-muted">
                    Showing <?php echo e($comments->firstItem()); ?> to <?php echo e($comments->lastItem()); ?> of <?php echo e($comments->total()); ?> comments
                </div>
                <?php echo e($comments->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-comments fa-4x text-muted mb-3"></i>
                <h5 class="text-muted">No comments found</h5>
                <p class="text-muted">
                    <?php if(request()->hasAny(['search', 'status', 'post'])): ?>
                        Try adjusting your filters or <a href="<?php echo e(route('admin.comments.index')); ?>">view all comments</a>.
                    <?php else: ?>
                        Comments will appear here when users start commenting on your posts.
                    <?php endif; ?>
                </p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Comment Statistics -->
<?php if($comments->total() > 0): ?>
<div class="card mt-4">
    <div class="card-header">
        <h6 class="card-title mb-0">Comment Statistics</h6>
    </div>
    <div class="card-body">
        <div class="row text-center">
            <?php
                $totalComments = \App\Models\PostComment::count();
                $approvedComments = \App\Models\PostComment::where('status', 'approved')->count();
                $pendingComments = \App\Models\PostComment::where('status', 'pending')->count();
                $spamComments = \App\Models\PostComment::where('status', 'spam')->count();
            ?>
            <div class="col-md-3">
                <h4 class="text-primary"><?php echo e($totalComments); ?></h4>
                <small class="text-muted">Total Comments</small>
            </div>
            <div class="col-md-3">
                <h4 class="text-success"><?php echo e($approvedComments); ?></h4>
                <small class="text-muted">Approved</small>
            </div>
            <div class="col-md-3">
                <h4 class="text-warning"><?php echo e($pendingComments); ?></h4>
                <small class="text-muted">Pending</small>
            </div>
            <div class="col-md-3">
                <h4 class="text-danger"><?php echo e($spamComments); ?></h4>
                <small class="text-muted">Spam</small>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function clearSelection() {
    document.querySelectorAll('input[name="items[]"]').forEach(checkbox => {
        checkbox.checked = false;
    });
    document.getElementById('select-all').checked = false;
    updateBulkActions();
}

function updateBulkActions() {
    const checkboxes = document.querySelectorAll('input[name="items[]"]:checked');
    const bulkActions = document.querySelector('.bulk-actions');
    const bulkCommentsInput = document.getElementById('bulk-comments');

    if (bulkActions) {
        bulkActions.style.display = checkboxes.length > 0 ? 'block' : 'none';
    }

    if (bulkCommentsInput) {
        const commentIds = Array.from(checkboxes).map(cb => cb.value);
        bulkCommentsInput.value = JSON.stringify(commentIds);
    }
}

function toggleSelectAll(selectAllCheckbox) {
    const checkboxes = document.querySelectorAll('input[name="items[]"]');
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAllCheckbox.checked;
    });
    updateBulkActions();
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\openclusters\resources\views\admin\comments\index.blade.php ENDPATH**/ ?>