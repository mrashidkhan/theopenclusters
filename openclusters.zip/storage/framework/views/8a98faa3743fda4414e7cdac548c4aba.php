<?php $__env->startSection('title', 'Staff Management'); ?>
<?php $__env->startSection('page-title', 'Staff Management'); ?>

<?php $__env->startSection('page-actions'); ?>
<a href="<?php echo e(route('admin.staff.create')); ?>" class="btn btn-primary">
    <i class="fas fa-plus me-2"></i>Add New Staff Member
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php if($staff->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Member</th>
                            <th>Position</th>
                            <th>Contact</th>
                            <th>Posts</th>
                            <th>Status</th>
                            <th>Joined</th>
                            <th width="150">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <img src="<?php echo e($member->avatar_url); ?>" class="rounded-circle me-3" width="50" height="50" alt="">
                                    <div>
                                        <a href="<?php echo e(route('admin.staff.show', $member)); ?>" class="text-decoration-none fw-medium">
                                            <?php echo e($member->name); ?>

                                        </a>
                                        <?php if($member->bio): ?>
                                            <div class="small text-muted"><?php echo e(Str::limit($member->bio, 60)); ?></div>
                                        <?php endif; ?>
                                        <div class="small">
                                            <code><?php echo e($member->slug); ?></code>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?php if($member->position): ?>
                                    <span class="badge bg-light text-dark"><?php echo e($member->position); ?></span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div>
                                    <div><i class="fas fa-envelope me-1"></i><?php echo e($member->email); ?></div>
                                    <?php if($member->phone): ?>
                                        <div><i class="fas fa-phone me-1"></i><?php echo e($member->phone); ?></div>
                                    <?php endif; ?>
                                    <?php if($member->social_links): ?>
                                        <div class="mt-1">
                                            <?php $__currentLoopData = $member->social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($url): ?>
                                                    <a href="<?php echo e($url); ?>" target="_blank" class="text-muted me-2" title="<?php echo e(ucfirst($platform)); ?>">
                                                        <i class="fab fa-<?php echo e($platform); ?>"></i>
                                                    </a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <div class="text-center">
                                    <span class="fw-bold"><?php echo e($member->posts_count); ?></span>
                                    <?php if($member->posts_count > 0): ?>
                                        <div>
                                            <a href="<?php echo e(route('admin.posts.index', ['author' => $member->id])); ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <?php if($member->status === 'active'): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($member->created_at->format('M d, Y')); ?>

                            </td>
                            <td>
                                <div class="table-actions">
                                    <a href="<?php echo e(route('admin.staff.show', $member)); ?>" class="btn btn-sm btn-outline-info" title="View Profile">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.staff.edit', $member)); ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>

                                    <form method="POST" action="<?php echo e(route('admin.staff.toggle-status', $member)); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-secondary" title="<?php echo e($member->status === 'active' ? 'Deactivate' : 'Activate'); ?>">
                                            <i class="fas fa-<?php echo e($member->status === 'active' ? 'toggle-on' : 'toggle-off'); ?>"></i>
                                        </button>
                                    </form>

                                    <?php if($member->posts_count === 0): ?>
                                    <form method="POST" action="<?php echo e(route('admin.staff.destroy', $member)); ?>" class="d-inline" onsubmit="return confirmDelete('Are you sure you want to delete this staff member?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                    <?php else: ?>
                                    <button class="btn btn-sm btn-outline-danger" disabled title="Cannot delete staff member with posts">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-between align-items-center mt-4">
                <div class="text-muted">
                    Showing <?php echo e($staff->firstItem()); ?> to <?php echo e($staff->lastItem()); ?> of <?php echo e($staff->total()); ?> staff members
                </div>
                <?php echo e($staff->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-users fa-4x text-muted mb-3"></i>
                <h5 class="text-muted">No staff members found</h5>
                <p class="text-muted">Get started by <a href="<?php echo e(route('admin.staff.create')); ?>">adding your first staff member</a>.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Staff Statistics -->
<?php if($staff->count() > 0): ?>
<div class="card mt-4">
    <div class="card-header">
        <h6 class="card-title mb-0">Staff Statistics</h6>
    </div>
    <div class="card-body">
        <div class="row text-center">
            <?php
                $totalStaff = $staff->total();
                $activeStaff = \App\Models\Staff::where('status', 'active')->count();
                $staffWithPosts = \App\Models\Staff::has('posts')->count();
                $totalPosts = \App\Models\Post::count();
            ?>
            <div class="col-md-3">
                <h4 class="text-primary"><?php echo e($totalStaff); ?></h4>
                <small class="text-muted">Total Staff</small>
            </div>
            <div class="col-md-3">
                <h4 class="text-success"><?php echo e($activeStaff); ?></h4>
                <small class="text-muted">Active Members</small>
            </div>
            <div class="col-md-3">
                <h4 class="text-info"><?php echo e($staffWithPosts); ?></h4>
                <small class="text-muted">Authors</small>
            </div>
            <div class="col-md-3">
                <h4 class="text-warning"><?php echo e($totalPosts); ?></h4>
                <small class="text-muted">Total Posts</small>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Tips -->
<div class="card mt-4">
    <div class="card-body">
        <h6><i class="fas fa-info-circle me-2"></i>Tips:</h6>
        <ul class="mb-0 small text-muted">
            <li>Staff members can be assigned as authors for blog posts</li>
            <li>Upload avatars for better profile presentation</li>
            <li>Add social media links to showcase team members</li>
            <li>Staff with posts cannot be deleted - reassign posts first</li>
            <li>Use descriptive positions to help visitors understand roles</li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\openclusters\resources\views\admin\staff\index.blade.php ENDPATH**/ ?>