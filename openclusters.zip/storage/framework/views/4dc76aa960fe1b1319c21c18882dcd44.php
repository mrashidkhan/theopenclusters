<?php $__env->startSection('title', 'Categories Management'); ?>
<?php $__env->startSection('page-title', 'Categories Management'); ?>

<?php $__env->startSection('page-actions'); ?>
<a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">
    <i class="fas fa-plus me-2"></i>Create New Category
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <?php if($categories->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover" id="categories-table">
                    <thead>
                        <tr>
                            <th width="50">Order</th>
                            <th>Name</th>
                            <th>Slug</th>
                            <th>Color</th>
                            <th>Posts</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th width="150">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="sortable-categories">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-id="<?php echo e($category->id); ?>">
                            <td>
                                <span class="badge bg-secondary"><?php echo e($category->sort_order); ?></span>
                                <i class="fas fa-grip-vertical text-muted ms-2" style="cursor: grab;"></i>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <?php if($category->icon): ?>
                                        <i class="<?php echo e($category->icon); ?> me-2" style="color: <?php echo e($category->color); ?>"></i>
                                    <?php endif; ?>
                                    <div>
                                        <a href="<?php echo e(route('admin.categories.show', $category)); ?>" class="text-decoration-none fw-medium">
                                            <?php echo e($category->name); ?>

                                        </a>
                                        <?php if($category->description): ?>
                                            <div class="small text-muted"><?php echo e(Str::limit($category->description, 60)); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <code class="small"><?php echo e($category->slug); ?></code>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="color-preview me-2" style="width: 20px; height: 20px; background-color: <?php echo e($category->color); ?>; border-radius: 3px; border: 1px solid #ddd;"></div>
                                    <code class="small"><?php echo e($category->color); ?></code>
                                </div>
                            </td>
                            <td>
                                <span class="fw-bold"><?php echo e($category->posts_count); ?></span>
                                <?php if($category->posts_count > 0): ?>
                                    <a href="<?php echo e(route('admin.posts.index', ['category' => $category->id])); ?>" class="btn btn-sm btn-outline-primary ms-1">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($category->status === 'active'): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($category->created_at->format('M d, Y')); ?>

                            </td>
                            <td>
                                <div class="table-actions">
                                    <a href="<?php echo e(route('admin.categories.show', $category)); ?>" class="btn btn-sm btn-outline-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>

                                    <form method="POST" action="<?php echo e(route('admin.categories.toggle-status', $category)); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-secondary" title="<?php echo e($category->status === 'active' ? 'Deactivate' : 'Activate'); ?>">
                                            <i class="fas fa-<?php echo e($category->status === 'active' ? 'toggle-on' : 'toggle-off'); ?>"></i>
                                        </button>
                                    </form>

                                    <?php if($category->posts_count === 0): ?>
                                    <form method="POST" action="<?php echo e(route('admin.categories.destroy', $category)); ?>" class="d-inline" onsubmit="return confirmDelete('Are you sure you want to delete this category?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                    <?php else: ?>
                                    <button class="btn btn-sm btn-outline-danger" disabled title="Cannot delete category with posts">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-between align-items-center mt-4">
                <div class="text-muted">
                    Showing <?php echo e($categories->firstItem()); ?> to <?php echo e($categories->lastItem()); ?> of <?php echo e($categories->total()); ?> categories
                </div>
                <?php echo e($categories->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-folder fa-4x text-muted mb-3"></i>
                <h5 class="text-muted">No categories found</h5>
                <p class="text-muted">Get started by <a href="<?php echo e(route('admin.categories.create')); ?>">creating your first category</a>.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Category Order Help -->
<div class="card mt-4">
    <div class="card-body">
        <h6><i class="fas fa-info-circle me-2"></i>Tips:</h6>
        <ul class="mb-0 small text-muted">
            <li>Drag categories to reorder them (affects display order on the frontend)</li>
            <li>Categories with posts cannot be deleted - move or delete posts first</li>
            <li>Use meaningful colors for better visual organization</li>
            <li>Icons use FontAwesome classes (e.g., fas fa-code, fas fa-paint-brush)</li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
<script>
// Make categories sortable
const sortableList = document.getElementById('sortable-categories');
if (sortableList) {
    const sortable = Sortable.create(sortableList, {
        handle: '.fa-grip-vertical',
        animation: 150,
        onEnd: function (evt) {
            updateCategoryOrder();
        }
    });
}

function updateCategoryOrder() {
    const rows = document.querySelectorAll('#sortable-categories tr');
    const categoriesData = [];

    rows.forEach((row, index) => {
        categoriesData.push({
            id: row.dataset.id,
            sort_order: index + 1
        });
    });

    fetch('<?php echo e(route("admin.categories.update-order")); ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        },
        body: JSON.stringify({
            categories: categoriesData
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update the order badges
            rows.forEach((row, index) => {
                const badge = row.querySelector('.badge');
                badge.textContent = index + 1;
            });
        }
    })
    .catch(error => {
        console.error('Error updating order:', error);
        alert('Failed to update category order');
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\openclusters\resources\views\admin\categories\index.blade.php ENDPATH**/ ?>