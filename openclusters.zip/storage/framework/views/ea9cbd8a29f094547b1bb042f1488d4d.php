<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Admin Dashboard'); ?> | <?php echo e(config('app.name')); ?></title>

    <!-- Favicon and touch Icons -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('img/favicon_io/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('img/favicon_io/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('img/favicon_io/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('img/favicon_io/site.webmanifest')); ?>">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Quill.js CSS -->
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

    <!-- Custom Admin CSS -->
    <style>
        /* Sidebar heading visibility fix */
        .sidebar .sidebar-heading {
            color: #16C60C !important;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 48px 0 0;
            box-shadow: inset -1px 0 0 rgba(0, 0, 0, .1);
            width: 250px;
            background-color: #212529;
        }

        .sidebar-sticky {
            position: relative;
            top: 0;
            height: calc(100vh - 48px);
            padding-top: .5rem;
            overflow-x: hidden;
            overflow-y: auto;
        }

        .sidebar .nav-link {
            color: #adb5bd;
            padding: 0.75rem 1rem;
            border-radius: 0;
        }

        .sidebar .nav-link:hover {
            color: #fff;
            background-color: #495057;
        }

        .sidebar .nav-link.active {
            color: #fff;
            background-color: #0d6efd;
        }

        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 16px;
        }

        .main-content {
            margin-left: 250px;
            padding-top: 48px;
        }

        .navbar-brand {
            padding-top: .75rem;
            padding-bottom: .75rem;
        }

        .navbar-nav .nav-link {
            padding-right: .5rem;
            padding-left: .5rem;
        }

        .card-stats {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
        }

        .card-stats-2 {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            border: none;
            color: white;
        }

        .card-stats-3 {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            border: none;
            color: white;
        }

        .card-stats-4 {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            border: none;
            color: white;
        }

        .table-actions {
            white-space: nowrap;
        }

        .table-actions .btn {
            padding: 0.25rem 0.5rem;
            margin: 0 0.125rem;
        }

        .status-badge {
            font-size: 0.75rem;
            padding: 0.25em 0.5em;
        }

        .featured-badge {
            background: linear-gradient(45deg, #ffd700, #ffed4e);
            color: #333;
            font-weight: bold;
        }

        /* Custom Quill.js Styles */
        .quill-editor-container {
            border: 1px solid #ced4da;
            border-radius: 0.375rem;
            background: white;
        }

        .quill-editor-container .ql-toolbar {
            border: none;
            border-bottom: 1px solid #ced4da;
            border-radius: 0.375rem 0.375rem 0 0;
        }

        .quill-editor-container .ql-container {
            border: none;
            border-radius: 0 0 0.375rem 0.375rem;
            font-size: 14px;
        }

        .quill-editor-container .ql-editor {
            min-height: 300px;
            max-height: 500px;
            overflow-y: auto;
        }

        .quill-editor-container .ql-editor.ql-blank::before {
            color: #6c757d;
            font-style: italic;
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <!-- Top Navigation -->
    <nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
        <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fas fa-cogs me-2"></i>Admin Panel
        </a>

        <div class="navbar-nav">
            <div class="nav-item text-nowrap">
                <a class="nav-link px-3" href="<?php echo e(route('index')); ?>" target="_blank">
                    <i class="fas fa-external-link-alt me-1"></i>View Site
                </a>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebarMenu" class="sidebar d-md-block bg-dark">
                <div class="sidebar-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.dashboard*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="fas fa-tachometer-alt"></i>
                                Dashboard
                            </a>
                        </li>
                    </ul>

                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        <span>Content Management</span>
                    </h6>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.posts*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.posts.index')); ?>">
                                <i class="fas fa-file-alt"></i>
                                Posts
                                <?php
                                    $draftCount = \App\Models\Post::where('status', 'draft')->count();
                                ?>
                                <?php if($draftCount > 0): ?>
                                    <span class="badge bg-warning text-dark ms-auto"><?php echo e($draftCount); ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.categories*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.categories.index')); ?>">
                                <i class="fas fa-folder"></i>
                                Categories
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.tags*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.tags.index')); ?>">
                                <i class="fas fa-tags"></i>
                                Tags
                            </a>
                        </li>
                    </ul>

                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        <span>Engagement</span>
                    </h6>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.comments*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.comments.index')); ?>">
                                <i class="fas fa-comments"></i>
                                Comments
                                <?php
                                    $pendingCount = \App\Models\PostComment::where('status', 'pending')->count();
                                ?>
                                <?php if($pendingCount > 0): ?>
                                    <span class="badge bg-danger ms-auto"><?php echo e($pendingCount); ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.comments.pending') ? 'active' : ''); ?>" href="<?php echo e(route('admin.comments.pending')); ?>">
                                <i class="fas fa-clock"></i>
                                Pending Comments
                                <?php if($pendingCount > 0): ?>
                                    <span class="badge bg-warning text-dark ms-auto"><?php echo e($pendingCount); ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                    </ul>

                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        <span>Team Management</span>
                    </h6>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.staff*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.staff.index')); ?>">
                                <i class="fas fa-users"></i>
                                Staff
                            </a>
                        </li>
                    </ul>

                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        <span>Quick Actions</span>
                    </h6>
                    <ul class="nav flex-column mb-2">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.posts.create')); ?>">
                                <i class="fas fa-plus"></i>
                                New Post
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.categories.create')); ?>">
                                <i class="fas fa-plus"></i>
                                New Category
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.staff.create')); ?>">
                                <i class="fas fa-plus"></i>
                                New Staff
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="main-content">
                <div class="container-fluid">
                    <!-- Page Header -->
                    <?php if(isset($pageTitle) || View::hasSection('page-title')): ?>
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h1 class="h2"><?php echo $__env->yieldContent('page-title', $pageTitle ?? ''); ?></h1>
                        <?php echo $__env->yieldContent('page-actions'); ?>
                    </div>
                    <?php endif; ?>

                    <!-- Flash Messages -->
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('warning')): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-triangle me-2"></i><?php echo e(session('warning')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Main Content Area -->
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Chart.js for dashboard -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Quill.js JS -->
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>

    <script>
        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                var alerts = document.querySelectorAll('.alert');
                alerts.forEach(function(alert) {
                    if (alert.querySelector('.btn-close')) {
                        alert.querySelector('.btn-close').click();
                    }
                });
            }, 5000);

            // Initialize Quill editors
            initializeQuillEditors();
        });

        // Initialize Quill.js editors
        function initializeQuillEditors() {
            const quillContainers = document.querySelectorAll('.quill-editor');

            quillContainers.forEach(function(container) {
                const editorId = container.getAttribute('data-editor-id');
                const textarea = document.getElementById(editorId);

                if (textarea && !container.querySelector('.ql-toolbar')) {
                    const quill = new Quill(container, {
                        theme: 'snow',
                        placeholder: 'Write your content here...',
                        modules: {
                            toolbar: [
                                [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
                                [{ 'font': [] }],
                                [{ 'size': ['small', false, 'large', 'huge'] }],
                                ['bold', 'italic', 'underline', 'strike'],
                                [{ 'color': [] }, { 'background': [] }],
                                [{ 'script': 'sub'}, { 'script': 'super' }],
                                [{ 'align': [] }],
                                [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                                [{ 'indent': '-1'}, { 'indent': '+1' }],
                                ['blockquote', 'code-block'],
                                ['link', 'image', 'video'],
                                ['clean']
                            ]
                        }
                    });

                    // Set initial content from textarea
                    if (textarea.value) {
                        quill.root.innerHTML = textarea.value;
                    }

                    // Sync content with hidden textarea on change
                    quill.on('text-change', function() {
                        textarea.value = quill.root.innerHTML;
                    });

                    // Also sync on form submission
                    const form = textarea.closest('form');
                    if (form) {
                        form.addEventListener('submit', function() {
                            textarea.value = quill.root.innerHTML;
                        });
                    }
                }
            });
        }

        // Function to reinitialize Quill editors (useful for dynamic content)
        function reinitializeQuillEditors() {
            initializeQuillEditors();
        }

        // Confirm delete actions
        function confirmDelete(message = 'Are you sure you want to delete this item?') {
            return confirm(message);
        }

        // Select All checkbox functionality
        function toggleSelectAll(selectAllCheckbox) {
            const checkboxes = document.querySelectorAll('input[name="items[]"]');
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAllCheckbox.checked;
            });
            updateBulkActions();
        }

        // Update bulk actions visibility
        function updateBulkActions() {
            const checkboxes = document.querySelectorAll('input[name="items[]"]:checked');
            const bulkActions = document.querySelector('.bulk-actions');
            if (bulkActions) {
                bulkActions.style.display = checkboxes.length > 0 ? 'block' : 'none';
            }
        }
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\Laravel\openclusters\resources\views\admin\layout\app.blade.php ENDPATH**/ ?>