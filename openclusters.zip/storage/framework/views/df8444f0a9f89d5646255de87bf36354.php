<?php $__env->startSection('title', 'Edit Comment'); ?>
<?php $__env->startSection('page-title', 'Edit Comment'); ?>

<?php $__env->startSection('page-actions'); ?>
<div class="d-flex gap-2">
    <a href="<?php echo e(route('admin.comments.index')); ?>" class="btn btn-secondary">
        <i class="fas fa-arrow-left me-2"></i>Back to Comments
    </a>
    <a href="<?php echo e(route('admin.comments.show', $comment)); ?>" class="btn btn-outline-info">
        <i class="fas fa-eye me-2"></i>View Comment
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8">
        <!-- Comment Form -->
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Comment Details</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.comments.update', $comment)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" id="name"
                                       class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('name', $comment->name)); ?>" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" id="email"
                                       class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('email', $comment->email)); ?>" required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="website" class="form-label">Website</label>
                        <input type="url" name="website" id="website"
                               class="form-control <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('website', $comment->website)); ?>"
                               placeholder="https://example.com">
                        <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="content" class="form-label">Comment <span class="text-danger">*</span></label>
                        <textarea name="content" id="content" rows="6"
                                  class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  required><?php echo e(old('content', $comment->content)); ?></textarea>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="status" class="form-label">Status</label>
                                <select name="status" id="status" class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="pending" <?php echo e(old('status', $comment->status) === 'pending' ? 'selected' : ''); ?>>Pending</option>
                                    <option value="approved" <?php echo e(old('status', $comment->status) === 'approved' ? 'selected' : ''); ?>>Approved</option>
                                    <option value="rejected" <?php echo e(old('status', $comment->status) === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                                    <option value="spam" <?php echo e(old('status', $comment->status) === 'spam' ? 'selected' : ''); ?>>Spam</option>
                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch mt-4">
                                    <input type="hidden" name="is_featured" value="0">
                                    <input class="form-check-input" type="checkbox" name="is_featured"
                                           id="is_featured" value="1"
                                           <?php echo e(old('is_featured', $comment->is_featured) ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="is_featured">
                                        Featured Comment
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="<?php echo e(route('admin.comments.index')); ?>" class="btn btn-secondary">Cancel</a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Update Comment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <!-- Comment Information -->
        <div class="card">
            <div class="card-header">
                <h6 class="card-title mb-0">Comment Information</h6>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label text-muted">Post</label>
                    <div>
                        <a href="<?php echo e(route('admin.posts.show', $comment->post)); ?>" class="text-decoration-none">
                            <?php echo e($comment->post->title); ?>

                        </a>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label text-muted">Submitted Date</label>
                    <div><?php echo e($comment->created_at->format('M d, Y h:i A')); ?></div>
                </div>

                <div class="mb-3">
                    <label class="form-label text-muted">Last Updated</label>
                    <div><?php echo e($comment->updated_at->format('M d, Y h:i A')); ?></div>
                </div>

                <div class="mb-3">
                    <label class="form-label text-muted">IP Address</label>
                    <div><?php echo e($comment->ip_address ?? 'Not recorded'); ?></div>
                </div>

                <?php if($comment->user_agent): ?>
                <div class="mb-3">
                    <label class="form-label text-muted">User Agent</label>
                    <div class="small text-break"><?php echo e(Str::limit($comment->user_agent, 100)); ?></div>
                </div>
                <?php endif; ?>

                <?php if($comment->parent_id): ?>
                <div class="mb-3">
                    <label class="form-label text-muted">Reply To</label>
                    <div>
                        <a href="<?php echo e(route('admin.comments.show', $comment->parent)); ?>" class="text-decoration-none">
                            <?php echo e($comment->parent->name); ?>

                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label text-muted">Avatar</label>
                    <div>
                        <img src="<?php echo e($comment->avatar); ?>" class="rounded-circle" width="50" height="50" alt="<?php echo e($comment->name); ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card mt-3">
            <div class="card-header">
                <h6 class="card-title mb-0">Quick Actions</h6>
            </div>
            <div class="card-body">
                <?php if($comment->status === 'pending'): ?>
                <form method="POST" action="<?php echo e(route('admin.comments.approve', $comment)); ?>" class="d-inline-block w-100 mb-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="btn btn-success w-100">
                        <i class="fas fa-check me-2"></i>Approve Comment
                    </button>
                </form>
                <?php endif; ?>

                <?php if($comment->status !== 'rejected'): ?>
                <form method="POST" action="<?php echo e(route('admin.comments.reject', $comment)); ?>" class="d-inline-block w-100 mb-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <button type="submit" class="btn btn-warning w-100">
                        <i class="fas fa-times me-2"></i>Reject Comment
                    </button>
                </form>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('admin.comments.destroy', $comment)); ?>"
                      class="d-inline-block w-100"
                      onsubmit="return confirm('Are you sure you want to delete this comment? This action cannot be undone.')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger w-100">
                        <i class="fas fa-trash me-2"></i>Delete Comment
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\openclusters\resources\views\admin\comments\edit.blade.php ENDPATH**/ ?>